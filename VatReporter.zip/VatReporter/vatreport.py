import os
os.chdir(r"C:\Users\hathanikal\Music\Project\VatReporter")
print(os.getcwd())

