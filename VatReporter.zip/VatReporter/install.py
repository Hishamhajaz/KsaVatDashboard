import subprocess; subprocess.check_call(["python", "-m", "pip", "install", "streamlit pandas plotly numpy"])
