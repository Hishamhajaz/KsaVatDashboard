import subprocess
import os

# Navigate to correct folder
os.chdir(r"C:\Users\hathanikal\Music\Project\VatReporter")

# LOCALHOST ONLY - NO NETWORK ACCESS
subprocess.Popen([
    "python", "-m", "streamlit", "run", 
    "app.py",
    "--server.address", "127.0.0.1",
    "--server.port", "8501"
])

print("🔒 LOCALHOST ONLY DASHBOARD")
print("✅ Open: http://localhost:8501")
print("🚫 NO network URL shown!")
