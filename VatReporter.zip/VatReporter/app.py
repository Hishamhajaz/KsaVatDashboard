import streamlit as st
import pandas as pd

st.set_page_config(layout="wide")
st.title("🕌 KSA VAT Compliance Reporter - YOUR DATA")
st.warning("🔒 LOCALHOST ONLY - Secure")

# UPLOAD YOUR CSV
uploaded_file = st.file_uploader("📁 Upload invoices.csv", type="csv")

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    
    # VAT METRICS
    col1, col2, col3 = st.columns(3)
    col1.metric("📊 Total Invoices", len(df))
    col2.metric("💰 Grand Total", f"SAR {df['total'].sum():,.0f}")
    col3.metric("🧾 Total VAT", f"SAR {df['vat_amount'].sum():,.0f}")
    
    # SHOW YOUR INVOICES
    st.subheader("📋 Your Invoices")
    st.dataframe(df)
    
    # ANOMALY DETECTION
    anomalies = df[df['status'] == 'ANOMALY']
    if len(anomalies) > 0:
        st.error(f"🚨 {len(anomalies)} ANOMALIES - ZATCA Risk!")
        st.dataframe(anomalies)
    
    # ZATCA QR GENERATOR
    st.subheader("🖼️ Generate ZATCA QR Code")
    selected_invoice = st.selectbox("Select Invoice", df['invoice_id'])
    row = df[df['invoice_id'] == selected_invoice].iloc[0]
    
    if st.button("✅ Generate ZATCA QR Code"):
        qr_info = f"""
SELLER: {row['seller_name']}
VAT ID: 300123456700003
INVOICE: {row['invoice_id']}
TOTAL: SAR {row['total']}
VAT 15%: SAR {row['vat_amount']}
STATUS: {row['status']}
        """
        st.success("✅ ZATCA QR Code Generated!")
        st.code(qr_info)

else:
    # SAMPLE DATA (when no file uploaded)
    st.info("👆 Upload your invoices.csv to see real data")
    
    sample_df = pd.DataFrame({
        'invoice_id': ['INV001', 'INV002', 'INV003'],
        'seller_name': ['ABC Trading', 'XYZ Corp', 'Riyadh Supplies'],
        'total': [11500, 5750, 23000],
        'vat_amount': [1500, 750, 3000],
        'status': ['Cleared', 'Reported', 'ANOMALY']
    })
    st.dataframe(sample_df)
