import subprocess
import os

os.chdir(r"C:\Users\hathanikal\Music\Project\VatReporter")

subprocess.Popen([
    "python", "-m", "streamlit", "run", 
    "app.py", 
    "--server.address", "127.0.0.1",
    "--server.port", "8501"
])

print("🚀 CSV VERSION LIVE: http://localhost:8501")
print("📁 Ready for YOUR invoice files!")
